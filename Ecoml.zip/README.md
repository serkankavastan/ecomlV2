# Example backend and client app
örnek bir link metni şu şekilde oluyor : [bu linke tıklayınız](http://google.com)

## example 2 

Work list;

- Main Folder
    - backend
    - client

test image;

![bu bir görseldir](https://octodex.github.com/images/yaktocat.png)

Bur bir blok denemesidir 'X' bu dfah geniş blok denemesidir : 'XXXX'

buda bir kod bloğudur;

> burda bir kod geliştirmesi örneği veilir yada özel bir açıklama yapılır
> - Burda yazar adı gibi özel bilgiler olmalıdır.


